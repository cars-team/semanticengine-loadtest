#!/bin/bash

cp files/lsa_experiments_ab.ttl files/lsa_experiments_tb.ttl files/semanticengine-1.0.1-SNAPSHOT-jar-with-dependencies.jar docker-engine/engine/
cp files/locustfile.py docker-locust/locust-master/
cp files/locustfile.py docker-locust/locust-slave/

#docker-compose stop
#docker-compose rm
cp engine.env docker-engine/.env
cd docker-engine/
docker-compose build
#docker-compose --compatibility up -d

docker-compose -f docker-compose-locust.yml build
